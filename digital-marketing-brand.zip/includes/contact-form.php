<form class="row gx-4" id="contactForm" action="" method="POST">
                                 <div class="col-12 col-sm-6">
                                    <input class="form-control" placeholder="Enter Your Name" type="text" name="name" />
                                 </div>
                                 <div class="col-12 col-sm-6">
                                    <input class="form-control" placeholder="Enter Your Email" type="text" name="email" />
                                 </div>
                                 <div class="col-12">
                                    <select id="inputState" class="form-select">
                                       <option selected>Choose Service</option>
                                       <option>Search Engine Optimization</option>
                                       <option>Pay Per Click</option>
                                       <option>Social Media Marketing</option>
                                       <option>Content Marketing Services</option>
                                       <option>Web Development Services</option>
                                       <option>Web Design Services</option>
                                    </select>
                                 </div>
                                 <div class="col-12">
                                    <textarea placeholder="Type your question" class="form-control textarea-control" name="message" id="textarea" cols="30" rows="10"></textarea>
                                 </div>
                                 <div class="col-12">
                                    <button type="submit" class="btn btn-warning">
                                    Submit
                                    <i class="icofont-rounded-double-right"></i>
                                    </button>
                                 </div>
                              </form>
                              <p class="form-message"></p>