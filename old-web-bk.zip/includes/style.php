<!-- Favicon -->
      <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico" />
      <link rel="stylesheet" href="assets/css/vendor/icofont.min.css" />
      <link rel="stylesheet" href="assets/css/plugins/animate.min.css" />
      <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css" />
      <link rel="stylesheet" href="assets/css/plugins/aos.css" />
      <link rel="stylesheet" href="assets/css/plugins/selectric.css" />
      <link rel="stylesheet" href="assets/css/style.css" />
      <link rel="stylesheet" href="assets/css/custom.css" />