<script src="assets/js/vendor/vendor.min.js"></script>
      <script src="assets/js/plugins/plugins.min.js"></script>
      <script src="assets/js/ajax-contact.js"></script>
      <script src="assets/js/plugins/aos.js"></script>
      <script src="assets/js/plugins/waypoints.js"></script>
      <script src="assets/js/plugins/jquery.selectric.min.js"></script>
      <script src="assets/js/main.min.js"></script>